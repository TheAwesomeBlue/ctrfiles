var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-26679617-8']);
_gaq.push(['_setDomainName', 'cuttherope.net']);
_gaq.push(['_trackPageview']);