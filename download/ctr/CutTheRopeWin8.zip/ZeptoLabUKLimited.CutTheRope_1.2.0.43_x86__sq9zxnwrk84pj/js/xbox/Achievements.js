﻿(function () {

    var CTR_TITLE_ID = 0x5A511B59;

    WinJS.Namespace.define("ZL", {
        Achievements: {

            getUnlockedIds: function (callback) {

				var localFolder = Windows.Storage.ApplicationData.current.localFolder;
				localFolder.createFileAsync("achievements.json");

				function readAchievementIds(file) {
					Windows.Storage.FileIO.readTextAsync(file).done(function (earnedIds) {
						// write a placeholder bracket (so it can be JSON-certified)
						if (earnedIds == "") {
							Windows.Storage.FileIO.writeTextAsync(file, "[]");
							return; // return data, assuming this is their first time launching the game
						}
						
						// parse the earned achievements
						var earnedIds = JSON.parse(earnedIds);
						callback(earnedIds);
					}, achievementError);
				}

				function achievementError() {
					callback(null);
				}

				localFolder.getFileAsync('achievements.json')
					.done(readAchievementIds, achievementError);
            },

            // Unlocks an achievement and executes a callback upon completion.
            // The callback parameter will indicate whether the achievement was
            // successfully unlocked
            unlock: function (achievementId, callback) {

				var localFolder = Windows.Storage.ApplicationData.current.localFolder;
				
				function addAchievement(file) {
					Windows.Storage.FileIO.readTextAsync(file).done(function (earnedIds) {
						earnedIds = JSON.parse(earnedIds);
						earnedIds.push(achievementId);
						Windows.Storage.FileIO.writeTextAsync(file, JSON.stringify(earnedIds));
						callback(true);
					}, addAchievementError);
				}

				function addAchievementError() {
					callback(false);
				}

				localFolder.getFileAsync('achievements.json')
					.done(addAchievement, addAchievementError);
            }
        }
    });
})();
