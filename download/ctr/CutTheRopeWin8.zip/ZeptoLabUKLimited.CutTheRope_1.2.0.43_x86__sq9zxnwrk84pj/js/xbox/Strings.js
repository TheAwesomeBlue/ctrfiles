﻿// keep in sync with js/resources/XboxStringId.js
var XboxStringId = {
    XBOX_LIVE: 0,
    SIGN_OUT: 1,
    SIGN_IN: 2,
    SIGNING_IN: 3,
    GETTING_PROFILE: 4,
    PROFILE_NOT_FOUND: 5,
    CANNOT_SIGN_IN: 6
};
