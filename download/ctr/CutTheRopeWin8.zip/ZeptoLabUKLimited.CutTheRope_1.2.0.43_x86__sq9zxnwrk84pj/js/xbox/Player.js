﻿(function () {

    // cache sign-in related controls
    var $message, $signIn, $signOut, $gamerPicture,
        PENDING_CLASS = 'pending',
        setMessage = ZeptoLab.ctr.setSignInMessage,
        setGamertag = ZeptoLab.ctr.setSignInGamertag;
    
    WinJS.Namespace.define("ZL", {
        Player: {
            init: function () {
                $message = $('#signInMessage');
                $signIn = $('#signInButton').click($.proxy(this.signIn, this));
                $signOut = $('#signOutButton').click($.proxy(this.signOut, this)).hide();
                $gamerPicture = $('#gamerPicture');
            },
            signInPending: false,
            signIn: function () {
                if (this.signInPending) {
                    return;
                }

                this.signInPending = true;
                var signInCompleted = function () {
                    $signIn.removeClass(PENDING_CLASS);
                    this.signInPending = false;
                }.bind(this);

                $signIn.addClass(PENDING_CLASS);
                $signOut.hide();

                setMessage(XboxStringId.SIGNING_IN);

				$gamerPicture.css('background-image', 'url(/images/GreenSpirit_avatar_1280x1280.png)'); // profile picture
				
				setGamertag('TheGreenSpirit'); // self explanatory
				
				// Test max length gamertag
				//setGamertag('WWWWWMMMMMWWWWW');
				
				$signIn.hide();
				$signOut.show();
				signInCompleted();
				ZeptoLab.ctr.onUserIdChanged("zeptolab"); // id can be anything, it doesn't matter
				ZeptoLab.ctr.onSignIn();
            },
            signOut: function () {
                this.onSignedOut();
            },
            onSignedOut: function () {
                this.identity = null;
                this.profile = null;

                // reset sign in controls
                $gamerPicture.css('background-image', '');
                setMessage(XboxStringId.XBOX_LIVE);
                $signIn.show();
                $signOut.hide();
                ZeptoLab.ctr.onUserIdChanged(null);
                ZeptoLab.ctr.onSignOut();
            }
        }
    });
}());